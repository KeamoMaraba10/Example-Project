/**
 * @author Mr Orfao
 * (Firework Management Bureau)
 */
package acsse.csc2a.fmb.model;

import acsse.csc2a.fmb.gui.AbstractVisitable;
import acsse.csc2a.fmb.gui.AbstractVisitor;

/**
 * @author Mr J Orfao
 * @version P05
 */
public class FireworkEntity extends Entity implements AbstractVisitable {
	private final Firework firework;
	
	public FireworkEntity(int xLocation, double angle, Firework firework) {
		super(xLocation, angle);
		this.firework = firework;
	}
	
	public final Firework getFirework()
	{
		return firework;
	}
	
	@Override
	public String toString() {
		return String.format("%sFirework:\n%s\n", super.toString(), firework);

	}

	@Override
	public void accept(AbstractVisitor visitor) {
		// TODO Auto-generated method stub
		
			visitor.visit(this);
	
			
			
		}
	}



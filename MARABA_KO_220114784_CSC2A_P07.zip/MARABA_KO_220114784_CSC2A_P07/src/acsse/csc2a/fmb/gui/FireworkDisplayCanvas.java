package acsse.csc2a.fmb.gui;

import java.util.ArrayList;

import acsse.csc2a.fmb.model.FireworkEntity;
import acsse.csc2a.fmb.model.FountainFirework;
import acsse.csc2a.fmb.model.RocketFirework;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.BorderPane;

public class FireworkDisplayCanvas extends Canvas implements AbstractVisitable  {
	
	private static final int GRID_DIM = 15;
    private static final int CELL_DIM = 50;
    private static final int GRID_WIDTH = GRID_DIM * CELL_DIM;
    private static final int GRID_HEIGHT = GRID_DIM * CELL_DIM;
	
	private ArrayList<FireworkEntity> FWElist = new ArrayList<>();
	
	public FireworkDisplayCanvas() {
		 super(GRID_WIDTH, GRID_HEIGHT);	
	}
	
	public void redrawCanvas() {	
		GraphicsContext Gridgc = getGraphicsContext2D();
		Gridgc.clearRect(0, 0, GRID_WIDTH, GRID_HEIGHT);

        for (int i = 0; i <= GRID_DIM; i++) {
            double xLocation = i * CELL_DIM;
            Gridgc.strokeLine(0, xLocation, GRID_WIDTH, xLocation); 
            Gridgc.strokeLine(xLocation, 0, xLocation, GRID_HEIGHT);    
        }
        
	}

//this is the method for accepting firework entity visittor
	@Override
	public void accept(AbstractVisitor visitor) {
		// TODO Auto-generated method stub
		for(FireworkEntity fireworkEntity : FWElist ) {
			fireworkEntity.accept(visitor);//visitor design pattern
		}
	}









	




	
	
}

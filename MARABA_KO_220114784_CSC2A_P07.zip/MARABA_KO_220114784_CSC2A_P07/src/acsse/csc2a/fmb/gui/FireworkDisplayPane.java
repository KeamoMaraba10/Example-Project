package acsse.csc2a.fmb.gui;

import java.io.File;
import java.util.ArrayList;

import acsse.csc2a.fmb.file.OrchestratorFileHandler;
import acsse.csc2a.fmb.model.DisplayBundle;
import acsse.csc2a.fmb.model.E_COLOUR;
import acsse.csc2a.fmb.model.FireworkEntity;
import javafx.geometry.Insets;
import javafx.scene.control.Accordion;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.control.TitledPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class FireworkDisplayPane extends StackPane {
	//make instance variables for the following


	//Display Bundle
	private DisplayBundle objDisplayBundle ;
	OrchestratorFileHandler objHandler = new OrchestratorFileHandler();

	//private FireworkDisplayCanvas FWClass = new FireworkDisplayCanvas();
	private VBox vb = null;
	FireworkDisplayCanvas canvas = new FireworkDisplayCanvas();


	//constructor for Display pane. This makes the menu, the accordian and the canvas
	public FireworkDisplayPane(Stage stage) {

		this.vb = new VBox();
		vb.getChildren().add(this.makeMenu(stage));
		this.getChildren().add(vb);
		canvas.redrawCanvas();


	}
	
	//Display bundle creation method. This reads the given data file, and returns a display bundle
	public void makeDisplayBundle(File file) {

		String filename = file.getPath();
		String displayFilePath = "data/displays";

		this.objDisplayBundle = objHandler.readLayoutFile(filename, displayFilePath);
		this.makeAccordion();
		
	}
	
	//This creates a menu bar
	public MenuBar makeMenu(Stage primaryStage) {

		MenuBar mb = new MenuBar();
		Menu m = new Menu("File");
		mb.getMenus().add(m);
		MenuItem mItem1 = new MenuItem("open");
		m.getItems().add(mItem1);
		mItem1.setOnAction(event -> {chooseFile(primaryStage);} );//because lambda expressions are awesome

		return mb;
	}



	public void makeAccordion() {

		Accordion aco = new Accordion();
		if(this.objDisplayBundle != null) {

			TitledPane fdTP = new TitledPane();
			fdTP.setText("Firework Display");

			TitledPane ptTP = new TitledPane();
			ptTP.setText("Pyro Technician");

			GridPane fdGP = new GridPane();
			fdGP.add(new Label("DisplayID: "), 0, 0);
			fdGP.add(new TextField(objDisplayBundle.getDisplay().getDisplayID()), 1, 0);
			fdGP.add(new Label("Name: "), 0, 1);
			fdGP.add(new TextField(objDisplayBundle.getDisplay().getDisplayName()), 1, 1);
			fdGP.add(new Label("Theme: "), 0, 2);
			fdGP.add(new TextField(objDisplayBundle.getDisplay().getDisplayTheme()), 1, 2);

			GridPane ptGP = new GridPane();
			ptGP.add(new Label("PyroTechnician Name:"), 0, 0);
			ptGP.add(new TextField(objDisplayBundle.getDisplay().getLeadTechnician().getFullName()), 1, 0);

			ptGP.add(new Label("PyroTechnician Number:"), 0, 1);
			ptGP.add(new TextField(objDisplayBundle.getDisplay().getLeadTechnician().getPhoneNumber()), 1, 1);

			fdTP.setContent(fdGP);
			ptTP.setContent(ptGP);

			VBox fwVB = new VBox();

			ScrollPane fwSP = new ScrollPane();
			fwSP.setContent(fwVB);
			fwSP.setFitToWidth(true);


			//GridPane fwGP;

			//TitledPane fwTP = new TitledPane();

			for (FireworkEntity index : objDisplayBundle.getEntities()) {
				GridPane fwGP = new GridPane();
				fwGP.setPadding(new Insets(10)); 
				fwGP.add(new Label("ID: "), 0, 0); 
				fwGP.add(new TextField(index.getFirework().getFireworkID()), 1, 0);

				fwGP.add(new Label("Name: "), 0, 1);
				fwGP.add(new TextField(index.getFirework().getFireworkName()), 1, 1);

				fwGP.add(new Label("Fuse Length: "), 0, 2);
				fwGP.add(new TextField(String.valueOf(index.getFirework().getFuseLength())), 1, 2);

				fwGP.add(new Label("Color: "), 0, 3);
				fwGP.add(new TextField(String.valueOf(index.getFirework().getColour())), 1, 3);

				fwVB.getChildren().add(fwGP);
			}

			TitledPane fwTP = new TitledPane("Fireworks", fwSP);

			aco.getPanes().addAll(fdTP,ptTP);
			aco.getPanes().add(fwTP);

			BorderPane root = new BorderPane();
			root.setLeft(aco);

			this.getChildren().clear();
			this.getChildren().add(root);
			this.getChildren().add(canvas);

		} else {
			System.err.print("The display bundle does not exist. Check file handler");

		}


	}


	/**
	 * @author Keamogetswe
	 * this method takes in a primary stage, which will host the file chooser and allow you to create display bundle
	 */
	public void chooseFile(Stage stage) {
		FileChooser fc = new FileChooser();
		fc.setTitle("Choose a data file");
		File file = fc.showOpenDialog(stage);
		if(file != null) {
			makeDisplayBundle(file);
		}




	}




}

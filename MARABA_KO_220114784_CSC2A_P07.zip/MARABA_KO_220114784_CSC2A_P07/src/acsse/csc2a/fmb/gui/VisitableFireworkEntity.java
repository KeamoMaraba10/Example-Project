package acsse.csc2a.fmb.gui;

public interface VisitableFireworkEntity {
	
	public void accept();

}

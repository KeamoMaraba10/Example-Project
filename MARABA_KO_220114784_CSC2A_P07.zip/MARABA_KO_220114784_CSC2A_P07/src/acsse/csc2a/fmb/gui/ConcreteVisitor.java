/**
 * @author Keamogetswe
 */

package acsse.csc2a.fmb.gui;

import acsse.csc2a.fmb.model.FireworkEntity;
import acsse.csc2a.fmb.model.FountainFirework;
import acsse.csc2a.fmb.model.RocketFirework;
import javafx.scene.canvas.GraphicsContext;

public class ConcreteVisitor implements AbstractVisitor {

	@Override
	public void visit(FireworkEntity firework) {
		// TODO Auto-generated method stub
		
			if(firework.getFirework() instanceof RocketFirework ) {
				//couldn't implement the drawing logic
				
			

			} else if (firework.getFirework() instanceof FountainFirework) {
				
				//couldn't implement the drawing logic
			

			}
		
	}



	

}

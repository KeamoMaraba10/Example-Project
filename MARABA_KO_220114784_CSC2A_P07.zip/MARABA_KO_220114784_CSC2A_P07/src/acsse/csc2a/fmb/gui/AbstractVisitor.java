/**
 * @author Keamogetswe
 */

package acsse.csc2a.fmb.gui;

import acsse.csc2a.fmb.model.FireworkEntity;
import acsse.csc2a.fmb.model.FountainFirework;
import acsse.csc2a.fmb.model.RocketFirework;

public interface AbstractVisitor {
	
	public void visit(FireworkEntity firework);
	

}

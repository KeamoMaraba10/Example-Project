/**
 * @author Keamogetswe
 */

package acsse.csc2a.fmb.gui;

public interface AbstractVisitable {
	public void accept(AbstractVisitor visitor);
}
